package com.cg.capbook.exceptions;

public class InvalidSecurityAnswerQuestion extends Exception{

}
