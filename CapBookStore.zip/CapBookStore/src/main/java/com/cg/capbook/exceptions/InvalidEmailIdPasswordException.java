package com.cg.capbook.exceptions;

public class InvalidEmailIdPasswordException extends Exception{

}
